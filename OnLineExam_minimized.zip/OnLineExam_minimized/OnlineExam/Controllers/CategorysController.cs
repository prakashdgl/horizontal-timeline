using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class CategorysController : Controller
    {
		private readonly ICategoryRepository categoryRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public CategorysController() : this(new CategoryRepository())
        {
        }

        public CategorysController(ICategoryRepository categoryRepository)
        {
			this.categoryRepository = categoryRepository;
        }

        //
        // GET: /Categorys/

        public ViewResult Index(int? page)
        {
			var model = categoryRepository.GetAll(category => category.Exams, category => category.Links, category => category.Papers, category => category.Posts, category => category.Problems);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Categorys/Details/5

        public ViewResult Details(int id)
        {
			var model = categoryRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Categorys/Create

        public ActionResult Create()
        {
			var model = new Category();
            return View(model);
        } 

        //
        // POST: /Categorys/Create

        [HttpPost]
        public ActionResult Create(Category model)
        {
            if (ModelState.IsValid) {
                categoryRepository.Insert(model);
                categoryRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View(model);
			}
        }
        
        //
        // GET: /Categorys/Edit/5
 
        public ActionResult Edit(int id)
        {
			var model = categoryRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Categorys/Edit/5

        [HttpPost]
        public ActionResult Edit(Category model)
        {
            if (ModelState.IsValid) {
                categoryRepository.Update(model);
                categoryRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View(model);
			}
        }

        //
        // GET: /Categorys/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = categoryRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Categorys/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = categoryRepository.Single(t=>t.ID == id);
            categoryRepository.Delete(model);
            categoryRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

