using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class PostMetasController : Controller
    {
		private readonly IPostRepository postRepository;
		private readonly IPostMetaRepository postmetaRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public PostMetasController() : this(new PostRepository(), new PostMetaRepository())
        {
        }

        public PostMetasController(IPostRepository postRepository, IPostMetaRepository postmetaRepository)
        {
			this.postRepository = postRepository;
			this.postmetaRepository = postmetaRepository;
        }

        //
        // GET: /PostMetas/

        public ViewResult Index(int? page)
        {
			var model = postmetaRepository.GetAll(postmeta => postmeta.Post);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /PostMetas/Details/5

        public ViewResult Details(int id)
        {
			var model = postmetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /PostMetas/Create

        public ActionResult Create()
        {
			ViewBag.Post = postRepository.GetAll().ToSelectList(t => t.ID, t=>t.Body);
			var model = new PostMeta();
            return View(model);
        } 

        //
        // POST: /PostMetas/Create

        [HttpPost]
        public ActionResult Create(PostMeta model)
        {
            if (ModelState.IsValid) {
                postmetaRepository.Insert(model);
                postmetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Post = postRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /PostMetas/Edit/5
 
        public ActionResult Edit(int id)
        {
			//ViewBag.Post = postRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = postmetaRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /PostMetas/Edit/5

        [HttpPost]
        public ActionResult Edit(PostMeta model)
        {
            if (ModelState.IsValid) {
                postmetaRepository.Update(model);
                postmetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Post = postRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /PostMetas/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = postmetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /PostMetas/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = postmetaRepository.Single(t=>t.ID == id);
            postmetaRepository.Delete(model);
            postmetaRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

