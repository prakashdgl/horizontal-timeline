using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class LinksController : Controller
    {
		private readonly ICategoryRepository categoryRepository;
		private readonly ILinkRepository linkRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public LinksController() : this(new CategoryRepository(), new LinkRepository())
        {
        }

        public LinksController(ICategoryRepository categoryRepository, ILinkRepository linkRepository)
        {
			this.categoryRepository = categoryRepository;
			this.linkRepository = linkRepository;
        }

        //
        // GET: /Links/

        public ViewResult Index(int? page)
        {
			var model = linkRepository.GetAll(link => link.Category);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Links/Details/5

        public ViewResult Details(int id)
        {
			var model = linkRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Links/Create

        public ActionResult Create()
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new Link();
            return View(model);
        } 

        //
        // POST: /Links/Create

        [HttpPost]
        public ActionResult Create(Link model)
        {
            if (ModelState.IsValid) {
                linkRepository.Insert(model);
                linkRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /Links/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = linkRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Links/Edit/5

        [HttpPost]
        public ActionResult Edit(Link model)
        {
            if (ModelState.IsValid) {
                linkRepository.Update(model);
                linkRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /Links/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = linkRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Links/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = linkRepository.Single(t=>t.ID == id);
            linkRepository.Delete(model);
            linkRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

