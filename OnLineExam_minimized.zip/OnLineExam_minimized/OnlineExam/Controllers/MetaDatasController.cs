using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class MetaDatasController : Controller
    {
		private readonly IMetaDataRepository metadataRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public MetaDatasController() : this(new MetaDataRepository())
        {
        }

        public MetaDatasController(IMetaDataRepository metadataRepository)
        {
			this.metadataRepository = metadataRepository;
        }

        //
        // GET: /MetaDatas/

        public ViewResult Index(int? page)
        {
			var model = metadataRepository.GetAll();
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /MetaDatas/Details/5

        public ViewResult Details(int id)
        {
			var model = metadataRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /MetaDatas/Create

        public ActionResult Create()
        {
			var model = new MetaData();
            return View(model);
        } 

        //
        // POST: /MetaDatas/Create

        [HttpPost]
        public ActionResult Create(MetaData model)
        {
            if (ModelState.IsValid) {
                metadataRepository.Insert(model);
                metadataRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View(model);
			}
        }
        
        //
        // GET: /MetaDatas/Edit/5
 
        public ActionResult Edit(int id)
        {
			var model = metadataRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /MetaDatas/Edit/5

        [HttpPost]
        public ActionResult Edit(MetaData model)
        {
            if (ModelState.IsValid) {
                metadataRepository.Update(model);
                metadataRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View(model);
			}
        }

        //
        // GET: /MetaDatas/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = metadataRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /MetaDatas/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = metadataRepository.Single(t=>t.ID == id);
            metadataRepository.Delete(model);
            metadataRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

