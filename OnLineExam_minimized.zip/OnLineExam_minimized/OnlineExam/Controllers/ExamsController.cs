using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class ExamsController : Controller
    {
		private readonly ICategoryRepository categoryRepository;
		private readonly IExamRepository examRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public ExamsController() : this(new CategoryRepository(), new ExamRepository())
        {
        }

        public ExamsController(ICategoryRepository categoryRepository, IExamRepository examRepository)
        {
			this.categoryRepository = categoryRepository;
			this.examRepository = examRepository;
        }

        //
        // GET: /Exams/

        public ViewResult Index(int? page)
        {
			var model = examRepository.GetAll(exam => exam.Category, exam => exam.Attendances, exam => exam.ExamMetas);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Exams/Details/5

        public ViewResult Details(int id)
        {
			var model = examRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Exams/Create

        public ActionResult Create()
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new Exam();
            return View(model);
        } 

        //
        // POST: /Exams/Create

        [HttpPost]
        public ActionResult Create(Exam model)
        {
            if (ModelState.IsValid) {
                examRepository.Insert(model);
                examRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /Exams/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = examRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Exams/Edit/5

        [HttpPost]
        public ActionResult Edit(Exam model)
        {
            if (ModelState.IsValid) {
                examRepository.Update(model);
                examRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /Exams/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = examRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Exams/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = examRepository.Single(t=>t.ID == id);
            examRepository.Delete(model);
            examRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

