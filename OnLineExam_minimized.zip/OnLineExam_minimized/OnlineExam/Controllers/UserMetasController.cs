using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class UserMetasController : Controller
    {
		private readonly IUserRepository userRepository;
		private readonly IUserMetaRepository usermetaRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public UserMetasController() : this(new UserRepository(), new UserMetaRepository())
        {
        }

        public UserMetasController(IUserRepository userRepository, IUserMetaRepository usermetaRepository)
        {
			this.userRepository = userRepository;
			this.usermetaRepository = usermetaRepository;
        }

        //
        // GET: /UserMetas/

        public ViewResult Index(int? page)
        {
			var model = usermetaRepository.GetAll(usermeta => usermeta.User);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /UserMetas/Details/5

        public ViewResult Details(int id)
        {
			var model = usermetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /UserMetas/Create

        public ActionResult Create()
        {
			ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new UserMeta();
            return View(model);
        } 

        //
        // POST: /UserMetas/Create

        [HttpPost]
        public ActionResult Create(UserMeta model)
        {
            if (ModelState.IsValid) {
                usermetaRepository.Insert(model);
                usermetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /UserMetas/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = usermetaRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /UserMetas/Edit/5

        [HttpPost]
        public ActionResult Edit(UserMeta model)
        {
            if (ModelState.IsValid) {
                usermetaRepository.Update(model);
                usermetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /UserMetas/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = usermetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /UserMetas/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = usermetaRepository.Single(t=>t.ID == id);
            usermetaRepository.Delete(model);
            usermetaRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

