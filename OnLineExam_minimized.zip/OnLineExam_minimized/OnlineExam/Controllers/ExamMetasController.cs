using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class ExamMetasController : Controller
    {
		private readonly IExamRepository examRepository;
		private readonly IExamMetaRepository exammetaRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public ExamMetasController() : this(new ExamRepository(), new ExamMetaRepository())
        {
        }

        public ExamMetasController(IExamRepository examRepository, IExamMetaRepository exammetaRepository)
        {
			this.examRepository = examRepository;
			this.exammetaRepository = exammetaRepository;
        }

        //
        // GET: /ExamMetas/

        public ViewResult Index(int? page)
        {
			var model = exammetaRepository.GetAll(exammeta => exammeta.Exam);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /ExamMetas/Details/5

        public ViewResult Details(int id)
        {
			var model = exammetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /ExamMetas/Create

        public ActionResult Create()
        {
			//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new ExamMeta();
            return View(model);
        } 

        //
        // POST: /ExamMetas/Create

        [HttpPost]
        public ActionResult Create(ExamMeta model)
        {
            if (ModelState.IsValid) {
                exammetaRepository.Insert(model);
                exammetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /ExamMetas/Edit/5
 
        public ActionResult Edit(int id)
        {
			//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = exammetaRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /ExamMetas/Edit/5

        [HttpPost]
        public ActionResult Edit(ExamMeta model)
        {
            if (ModelState.IsValid) {
                exammetaRepository.Update(model);
                exammetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /ExamMetas/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = exammetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /ExamMetas/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = exammetaRepository.Single(t=>t.ID == id);
            exammetaRepository.Delete(model);
            exammetaRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

