using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class CommentsController : Controller
    {
		private readonly ICommentRepository commentRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public CommentsController() : this(new CommentRepository())
        {
        }

        public CommentsController(ICommentRepository commentRepository)
        {
			this.commentRepository = commentRepository;
        }

        //
        // GET: /Comments/

        public ViewResult Index(int? page)
        {
			var model = commentRepository.GetAll();
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Comments/Details/5

        public ViewResult Details(int id)
        {
			var model = commentRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Comments/Create

        public ActionResult Create()
        {
			var model = new Comment();
            return View(model);
        } 

        //
        // POST: /Comments/Create

        [HttpPost]
        public ActionResult Create(Comment model)
        {
            if (ModelState.IsValid) {
                commentRepository.Insert(model);
                commentRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View(model);
			}
        }
        
        //
        // GET: /Comments/Edit/5
 
        public ActionResult Edit(int id)
        {
			var model = commentRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Comments/Edit/5

        [HttpPost]
        public ActionResult Edit(Comment model)
        {
            if (ModelState.IsValid) {
                commentRepository.Update(model);
                commentRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View(model);
			}
        }

        //
        // GET: /Comments/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = commentRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Comments/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = commentRepository.Single(t=>t.ID == id);
            commentRepository.Delete(model);
            commentRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

