using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class PaperMetasController : Controller
    {
		private readonly IPaperRepository paperRepository;
		private readonly IPaperMetaRepository papermetaRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public PaperMetasController() : this(new PaperRepository(), new PaperMetaRepository())
        {
        }

        public PaperMetasController(IPaperRepository paperRepository, IPaperMetaRepository papermetaRepository)
        {
			this.paperRepository = paperRepository;
			this.papermetaRepository = papermetaRepository;
        }

        //
        // GET: /PaperMetas/

        public ViewResult Index(int? page)
        {
			var model = papermetaRepository.GetAll(papermeta => papermeta.Paper);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /PaperMetas/Details/5

        public ViewResult Details(int id)
        {
			var model = papermetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /PaperMetas/Create

        public ActionResult Create()
        {
			ViewBag.Paper = paperRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new PaperMeta();
            return View(model);
        } 

        //
        // POST: /PaperMetas/Create

        [HttpPost]
        public ActionResult Create(PaperMeta model)
        {
            if (ModelState.IsValid) {
                papermetaRepository.Insert(model);
                papermetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Paper = paperRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /PaperMetas/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.Paper = paperRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = papermetaRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /PaperMetas/Edit/5

        [HttpPost]
        public ActionResult Edit(PaperMeta model)
        {
            if (ModelState.IsValid) {
                papermetaRepository.Update(model);
                papermetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Paper = paperRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /PaperMetas/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = papermetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /PaperMetas/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = papermetaRepository.Single(t=>t.ID == id);
            papermetaRepository.Delete(model);
            papermetaRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

