using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class PostsController : Controller
    {
		private readonly IUserRepository userRepository;
		private readonly ICategoryRepository categoryRepository;
		private readonly IPostRepository postRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public PostsController() : this(new UserRepository(), new CategoryRepository(), new PostRepository())
        {
        }

        public PostsController(IUserRepository userRepository, ICategoryRepository categoryRepository, IPostRepository postRepository)
        {
			this.userRepository = userRepository;
			this.categoryRepository = categoryRepository;
			this.postRepository = postRepository;
        }

        //
        // GET: /Posts/

        public ViewResult Index(int? page)
        {
			var model = postRepository.GetAll(post => post.User, post => post.Category, post => post.PostMetas);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Posts/Details/5

        public ViewResult Details(int id)
        {
			var model = postRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Posts/Create

        public ActionResult Create()
        {
			ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new Post();
            return View(model);
        } 

        //
        // POST: /Posts/Create

        [HttpPost]
        public ActionResult Create(Post model)
        {
            if (ModelState.IsValid) {
                postRepository.Insert(model);
                postRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /Posts/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = postRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Posts/Edit/5

        [HttpPost]
        public ActionResult Edit(Post model)
        {
            if (ModelState.IsValid) {
                postRepository.Update(model);
                postRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /Posts/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = postRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Posts/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = postRepository.Single(t=>t.ID == id);
            postRepository.Delete(model);
            postRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

