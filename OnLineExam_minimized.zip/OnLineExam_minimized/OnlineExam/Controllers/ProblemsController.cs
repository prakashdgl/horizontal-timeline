using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class ProblemsController : Controller
    {
		private readonly ICategoryRepository categoryRepository;
		private readonly IProblemRepository problemRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public ProblemsController() : this(new CategoryRepository(), new ProblemRepository())
        {
        }

        public ProblemsController(ICategoryRepository categoryRepository, IProblemRepository problemRepository)
        {
			this.categoryRepository = categoryRepository;
			this.problemRepository = problemRepository;
        }

        //
        // GET: /Problems/

        public ViewResult Index(int? page)
        {
			var model = problemRepository.GetAll(problem => problem.Category, problem => problem.ProblemMetas);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Problems/Details/5

        public ViewResult Details(int id)
        {
			var model = problemRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Problems/Create

        public ActionResult Create()
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new Problem();
            return View(model);
        } 

        //
        // POST: /Problems/Create

        [HttpPost]
        public ActionResult Create(Problem model)
        {
            if (ModelState.IsValid) {
                problemRepository.Insert(model);
                problemRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /Problems/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = problemRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Problems/Edit/5

        [HttpPost]
        public ActionResult Edit(Problem model)
        {
            if (ModelState.IsValid) {
                problemRepository.Update(model);
                problemRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /Problems/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = problemRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Problems/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = problemRepository.Single(t=>t.ID == id);
            problemRepository.Delete(model);
            problemRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

