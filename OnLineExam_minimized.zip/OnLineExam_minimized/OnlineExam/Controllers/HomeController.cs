﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntityFramework.Patterns;
using OnlineExam.Entities;

namespace OnlineExam.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
			DbContextAdapter adp = new DbContextAdapter(new OnlineExamContext());
			IRepository<Category> catrep = new Repository<Category>(adp);
			var cats = catrep.GetAll(u => u.Posts);

			return Content("Count: " + cats.Count());
        }

    }
}
