using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class ProblemMetasController : Controller
    {
		private readonly IProblemRepository problemRepository;
		private readonly IProblemMetaRepository problemmetaRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public ProblemMetasController() : this(new ProblemRepository(), new ProblemMetaRepository())
        {
        }

        public ProblemMetasController(IProblemRepository problemRepository, IProblemMetaRepository problemmetaRepository)
        {
			this.problemRepository = problemRepository;
			this.problemmetaRepository = problemmetaRepository;
        }

        //
        // GET: /ProblemMetas/

        public ViewResult Index(int? page)
        {
			var model = problemmetaRepository.GetAll(problemmeta => problemmeta.Problem);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /ProblemMetas/Details/5

        public ViewResult Details(int id)
        {
			var model = problemmetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /ProblemMetas/Create

        public ActionResult Create()
        {
			//ViewBag.Problem = problemRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new ProblemMeta();
            return View(model);
        } 

        //
        // POST: /ProblemMetas/Create

        [HttpPost]
        public ActionResult Create(ProblemMeta model)
        {
            if (ModelState.IsValid) {
                problemmetaRepository.Insert(model);
                problemmetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Problem = problemRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /ProblemMetas/Edit/5
 
        public ActionResult Edit(int id)
        {
			//ViewBag.Problem = problemRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = problemmetaRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /ProblemMetas/Edit/5

        [HttpPost]
        public ActionResult Edit(ProblemMeta model)
        {
            if (ModelState.IsValid) {
                problemmetaRepository.Update(model);
                problemmetaRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Problem = problemRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /ProblemMetas/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = problemmetaRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /ProblemMetas/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = problemmetaRepository.Single(t=>t.ID == id);
            problemmetaRepository.Delete(model);
            problemmetaRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

