using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class PapersController : Controller
    {
		private readonly ICategoryRepository categoryRepository;
		private readonly IPaperRepository paperRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public PapersController() : this(new CategoryRepository(), new PaperRepository())
        {
        }

        public PapersController(ICategoryRepository categoryRepository, IPaperRepository paperRepository)
        {
			this.categoryRepository = categoryRepository;
			this.paperRepository = paperRepository;
        }

        //
        // GET: /Papers/

        public ViewResult Index(int? page)
        {
			var model = paperRepository.GetAll(paper => paper.Category, paper => paper.PaperMetas);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Papers/Details/5

        public ViewResult Details(int id)
        {
			var model = paperRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Papers/Create

        public ActionResult Create()
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new Paper();
            return View(model);
        } 

        //
        // POST: /Papers/Create

        [HttpPost]
        public ActionResult Create(Paper model)
        {
            if (ModelState.IsValid) {
                paperRepository.Insert(model);
                paperRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /Papers/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = paperRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Papers/Edit/5

        [HttpPost]
        public ActionResult Edit(Paper model)
        {
            if (ModelState.IsValid) {
                paperRepository.Update(model);
                paperRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.Category = categoryRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /Papers/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = paperRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Papers/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = paperRepository.Single(t=>t.ID == id);
            paperRepository.Delete(model);
            paperRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

