using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.EnumerableExtensions;
using MvcContrib.Pagination;
using OnlineExam.Entities;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{   
    public class AttendancesController : Controller
    {
		private readonly IExamRepository examRepository;
		private readonly IUserRepository userRepository;
		private readonly IAttendanceRepository attendanceRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public AttendancesController() : this(new ExamRepository(), new UserRepository(), new AttendanceRepository())
        {
        }

        public AttendancesController(IExamRepository examRepository, IUserRepository userRepository, IAttendanceRepository attendanceRepository)
        {
			this.examRepository = examRepository;
			this.userRepository = userRepository;
			this.attendanceRepository = attendanceRepository;
        }

        //
        // GET: /Attendances/

        public ViewResult Index(int? page)
        {
			var model = attendanceRepository.GetAll(attendance => attendance.Exam, attendance => attendance.User);
            return View(model.AsPagination(page ?? 1, Config.GetInt("PageSize")));
        }

        //
        // GET: /Attendances/Details/5

        public ViewResult Details(int id)
        {
			var model = attendanceRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // GET: /Attendances/Create

        public ActionResult Create()
        {
			//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			//ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = new Attendance();
            return View(model);
        } 

        //
        // POST: /Attendances/Create

        [HttpPost]
        public ActionResult Create(Attendance model)
        {
            if (ModelState.IsValid) {
                attendanceRepository.Insert(model);
                attendanceRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				//ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }
        
        //
        // GET: /Attendances/Edit/5
 
        public ActionResult Edit(int id)
        {
			//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			//ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
			var model = attendanceRepository.Single(t=>t.ID == id);
             return View(model);
        }

        //
        // POST: /Attendances/Edit/5

        [HttpPost]
        public ActionResult Edit(Attendance model)
        {
            if (ModelState.IsValid) {
                attendanceRepository.Update(model);
                attendanceRepository.Save();
                return RedirectToAction("Index");
            } else {
				//ViewBag.Exam = examRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				//ViewBag.User = userRepository.GetAll().ToSelectList(t => t.ID, t=>t.Name);
				return View(model);
			}
        }

        //
        // GET: /Attendances/Delete/5
 
        public ActionResult Delete(int id)
        {
			var model = attendanceRepository.Single(t=>t.ID == id);
            return View(model);
        }

        //
        // POST: /Attendances/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
			var model = attendanceRepository.Single(t=>t.ID == id);
            attendanceRepository.Delete(model);
            attendanceRepository.Save();

            return RedirectToAction("Index");
        }
    }
}

