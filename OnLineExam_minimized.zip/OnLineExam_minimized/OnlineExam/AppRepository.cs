﻿using EntityFramework.Patterns;

namespace OnlineExam
{
	public class AppRepository<T> : Repository<T> where T : class
	{
		private DbContextAdapter adapter;

		public AppRepository() : this(new DbContextAdapter(new OnlineExamContext())) { }

		public AppRepository(DbContextAdapter adapter) : base(adapter)
		{
			this.adapter = adapter;
		}

		public void Save()
		{
			adapter.SaveChanges();
		}
	}

	public interface IAppRepository<T> : IRepository<T> where T : class
	{
		void Save();
	}
}