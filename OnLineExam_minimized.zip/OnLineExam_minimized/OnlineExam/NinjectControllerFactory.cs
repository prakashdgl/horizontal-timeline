﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ninject;
using System.Web.Mvc;

namespace OnlineExam
{
	public class NinjectControllerFactory : DefaultControllerFactory
	{
		private IKernel kernel;

		public NinjectControllerFactory(IKernel kernel)
		{
			this.kernel = kernel;
		}

		protected override IController GetControllerInstance(System.Web.Routing.RequestContext requestContext, Type controllerType)
		{
			if (controllerType == null)
				return null;

			return (IController)kernel.Get(controllerType);
		}
	}
}