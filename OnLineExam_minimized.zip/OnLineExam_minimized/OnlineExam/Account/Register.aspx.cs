﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using OnlineExam.Models;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.WebControls;

namespace OnlineExam.Account
{
    public partial class Register : Page
    {
        protected void CreateUser_Click(object sender, EventArgs e)
        {
            //Get client IP Address and check if already exists in db. One IP Address per login
            string strIPAddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? Request.ServerVariables["REMOTE_ADDR"];

            //SqlCommand comm = new SqlCommand("uspCheckLockout", connObj);

            //comm.CommandType = CommandType.StoredProcedure;

            //comm.Parameters.Add(new SqlParameter("@Studentname", studentName));
            //comm.Parameters.Add(new SqlParameter("@LockoutTime", lockoutTime));

            //var returnParam = new SqlParameter
            //{
            //    ParameterName = "@return",
            //    Direction = ParameterDirection.ReturnValue
            //};

            //comm.Parameters.Add(returnParam);

            //comm.ExecuteNonQuery();

            //var isLocked = (int)returnParam.Value;
            //connObj.Close();



            var manager = Context.GetOwinContext().GetUserManager<ApplicationUserManager>();
            var signInManager = Context.GetOwinContext().Get<ApplicationSignInManager>();
            var user = new ApplicationUser() { UserName = Email.Text, Email = Email.Text, FirstName = txtFirstName.Text, LastName = txtLastName.Text, IPAddress = strIPAddress, MobileNumber = txtMobileNo.Text , EducationID = Convert.ToString(DDEducation.SelectedValue), BoardID = Convert.ToString(DDBoard.SelectedValue) };
            IdentityResult result = manager.Create(user, Password.Text);
            if (result.Succeeded)
            {
                // For more information on how to enable account confirmation and password reset please visit https://go.microsoft.com/fwlink/?LinkID=320771
                string code = manager.GenerateEmailConfirmationToken(user.Id);
                string callbackUrl = IdentityHelper.GetUserConfirmationRedirectUrl(code, user.Id, Request);
                manager.SendEmail(user.Id, "Confirm your account", "Please confirm your account by clicking <a href=\"" + callbackUrl + "\">here</a>.");
                if (user.EmailConfirmed)
                {
                    signInManager.SignIn(user, isPersistent: false, rememberBrowser: false);
                    IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
                }
                {
                    ErrorMessage.Text = "An email has been sent to your account. Please view the email and confirm your account to complete the registration process.";
                }
            }
            else 
            {
                ErrorMessage.Text = result.Errors.FirstOrDefault();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            LoadDDEducation();
            LoadDDBoard();
        }

        private void LoadDDEducation()
        {
            DDEducation.Items.Clear();
            SqlConnection connObj = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            SqlCommand cmd = new SqlCommand("GetDDEducation", connObj);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader reader;

            try
            {
                ListItem newItem = new ListItem();
                connObj.Open();

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    newItem = new ListItem();
                    newItem.Text = reader["EducationName"].ToString();
                    newItem.Value = reader["EducationID"].ToString();
                    DDEducation.Items.Add(newItem);
                }
                reader.Close();
            }
            catch (Exception err)
            {
                //TODO
            }
            finally
            {
                connObj.Close();
            }
        }

        private void LoadDDBoard()
        {
            DDBoard.Items.Clear();
            SqlConnection connObj = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            SqlCommand cmd = new SqlCommand("GetDDBoard", connObj);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader reader;

            try
            {
                ListItem newItem = new ListItem();
                connObj.Open();

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    newItem = new ListItem();
                    newItem.Text = reader["BoardName"].ToString();
                    newItem.Value = reader["BoardID"].ToString();
                    DDBoard.Items.Add(newItem);
                }
                reader.Close();
            }
            catch (Exception err)
            {
                //TODO
            }
            finally
            {
                connObj.Close();
            }
        }
    }
}