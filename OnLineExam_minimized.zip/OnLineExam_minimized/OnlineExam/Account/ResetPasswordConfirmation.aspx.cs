﻿using System.Web.UI;

namespace OnlineExam.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}