﻿using System;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using OnlineExam.Models;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web.UI.WebControls;

namespace OnlineExam.Account
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterHyperLink.NavigateUrl = "Register";
            // Enable this once you have account confirmation enabled for password reset functionality
            ForgotPasswordHyperLink.NavigateUrl = "Forgot";
            OpenAuthLogin.ReturnUrl = Request.QueryString["ReturnUrl"];
            if (String.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
            {             
                RegisterHyperLink.NavigateUrl += "?ReturnUrl=" +   "~/Dashboard";

            }
 
        }

        protected void LogIn(object sender, EventArgs e)
        {
            if (IsValid)
            {
                // Validate the user password
                var manager = Context.GetOwinContext().GetUserManager<ApplicationUserManager>();
                var signinManager = Context.GetOwinContext().GetUserManager<ApplicationSignInManager>();
                // Require the user to have a confirmed email before they can log on.
                var user = manager.FindByName(Email.Text);
                if (user != null)
                {
                    if (!user.EmailConfirmed)
                    {
                        FailureText.Text = "Invalid login attempt. You must have a confirmed email account.";
                        ErrorMessage.Visible = true;
                    }
                    else
                    {
                        // This doen't count login failures towards account lockout
                        // To enable password failures to trigger lockout, change to shouldLockout: true
                        var result = signinManager.PasswordSignIn(Email.Text, Password.Text, RememberMe.Checked, shouldLockout: false);

                        switch (result)
                        {
                            case SignInStatus.Success:
                                var strusermailid = Email.Text;
                                string strUserID="";
                                int intUserID=0;
                                //Call Stored Procedure to set the UserID in Session
                                //try
                                //{
                                //    string connstring = System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
                                //    //Create the connection object
                                //    using (SqlConnection conn = new SqlConnection(connstring))
                                //    {
                                //        // Open the SqlConnection.
                                //        conn.Open();
                                //        //Create the SQLCommand object
                                //        using (SqlCommand command = new SqlCommand("spFindUser", conn) { CommandType = System.Data.CommandType.StoredProcedure })
                                //        {
                                //            //Pass the parameter values here
                                //            command.Parameters.AddWithValue("@EMailID", strusermailid);
                                             
                                //            using (SqlDataReader reader = command.ExecuteReader())
                                //            {
                                //                //read the data
                                //                while (reader.Read())
                                //                {
                                //                    strUserID = reader["ID"].ToString();
                                //                    intUserID = reader["UserID"] == null ? 0 : Convert.ToInt32(reader["UserID"]);
                                //                    //GlobalVariables.strUserID = reader["ID"].ToString();
                                //                    //GlobalVariables.intUserID = = reader["UserID"] == null ? 0 : Convert.ToInt32(reader["UserID"]);
                                //                }
                                //            }
                                //        }
                                //        conn.Close();
                                //    }
                                    
                                //}
                                //catch (Exception ex)
                                //{
                                //    using (EventLog eventLog = new EventLog("Application"))
                                //    {
                                //        eventLog.Source = "Application";
                                //        eventLog.WriteEntry("Error in Database Operation @ Login Module" , EventLogEntryType.Error, 101, 1);
                                //    }
                                //}
                                //Session["strUserID"] = strUserID;
                                //Session["intUserID"] = intUserID;
                                //Label lblMasterStatus = (Label) Master.FindControl("lblUserID");
                                //lblMasterStatus.Text =intUserID.ToString();
                                //Server.Transfer("~/Dashboard");
                                IdentityHelper.RedirectToReturnUrl("~/Dashboard",Response);
                                //IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
                                //
                                break;
                            case SignInStatus.LockedOut:
                                Response.Redirect("/Account/Lockout");
                                break;
                            case SignInStatus.RequiresVerification:
                                Response.Redirect(String.Format("/Account/TwoFactorAuthenticationSignIn?ReturnUrl={0}&RememberMe={1}",
                                                                Request.QueryString["ReturnUrl"],
                                                                RememberMe.Checked),
                                                  true);
                                break;
                            case SignInStatus.Failure:
                            default:
                                FailureText.Text = "Invalid login attempt";
                                ErrorMessage.Visible = true;
                                break;
                        }
                    }
                }
            }
        }
    }
}