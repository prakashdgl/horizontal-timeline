﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Collections.Generic;

namespace OnlineExam
{
    public partial class QuestionsImage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated)
            { Response.Redirect("/Account/Login"); }
            if (!IsPostBack)
            {
                string[] filePaths = Directory.GetFiles(Server.MapPath("~/Images/"));
                List<ListItem> files = new List<ListItem>();
                foreach (string filePath in filePaths)
                {
                    string fileName = Path.GetFileName(filePath);
                    files.Add(new ListItem(fileName, "~/Images/" + fileName));
                }
                GridView1.DataSource = files;
                GridView1.DataBind();
            }
        }
        protected void ddBook_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddLesson.DataBind();
        }
        protected void ddLesson_SelectedIndexChanged(object sender, EventArgs e)
        {
            //GridView1.DataBind();
        }
        protected void ddQuestionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //GridView1.DataBind();
        }
        protected void ButtonAdd_Click(object sender, EventArgs e)
        {

            SqlDataSource2.InsertParameters["LessonNo"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("TextBox12")).Text;
            SqlDataSource2.InsertParameters["LessonName"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("TextBox13")).Text;
            SqlDataSource2.InsertParameters["TermNo"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("TextBox14")).Text;
            SqlDataSource2.InsertParameters["SubjectGradeBookID"].DefaultValue = ddBook.SelectedValue;
            SqlDataSource2.Insert();
        }
        protected void Upload(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Images/") + fileName);
                Response.Redirect(Request.Url.AbsoluteUri);
            }
        }

    }
}