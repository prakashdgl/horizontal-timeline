using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class LinkMap : EntityTypeConfiguration<Link>
	{
		public LinkMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.Url)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.Name)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.Description)
				.IsRequired()
				.HasMaxLength(256);
				
			// Table & Column Mappings
			this.ToTable("Links");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.Url).HasColumnName("Url");
			this.Property(t => t.Name).HasColumnName("Name");
			this.Property(t => t.Description).HasColumnName("Description");
			this.Property(t => t.CategoryID).HasColumnName("CategoryID");

			// Relationships
			this.HasRequired(t => t.Category)
				.WithMany(t => t.Links)
				.HasForeignKey(d => d.CategoryID);
				
		}
	}
}

