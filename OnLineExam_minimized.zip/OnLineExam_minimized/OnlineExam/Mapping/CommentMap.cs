using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class CommentMap : EntityTypeConfiguration<Comment>
	{
		public CommentMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.Target)
				.IsRequired()
				.HasMaxLength(50);
				
			this.Property(t => t.Name)
				.IsRequired()
				.HasMaxLength(50);
				
			this.Property(t => t.Email)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.IP)
				.IsRequired()
				.HasMaxLength(50);
				
			this.Property(t => t.Body)
				.IsRequired();
				
			// Table & Column Mappings
			this.ToTable("Comments");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.Target).HasColumnName("Target");
			this.Property(t => t.TargetID).HasColumnName("TargetID");
			this.Property(t => t.Name).HasColumnName("Name");
			this.Property(t => t.Email).HasColumnName("Email");
			this.Property(t => t.IP).HasColumnName("IP");
			this.Property(t => t.ParentID).HasColumnName("ParentID");
			this.Property(t => t.Body).HasColumnName("Body");
			this.Property(t => t.Status).HasColumnName("Status");
			this.Property(t => t.CreatedAt).HasColumnName("CreatedAt");
			this.Property(t => t.UpdatedAt).HasColumnName("UpdatedAt");
		}
	}
}

