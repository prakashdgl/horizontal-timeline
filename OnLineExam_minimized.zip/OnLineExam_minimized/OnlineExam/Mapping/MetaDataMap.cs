using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class MetaDataMap : EntityTypeConfiguration<MetaData>
	{
		public MetaDataMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.Family)
				.IsRequired()
				.HasMaxLength(50);
				
			this.Property(t => t.MetaKey)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.MetaValue)
				.IsRequired();
				
			// Table & Column Mappings
			this.ToTable("MetaDatas");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.Family).HasColumnName("Family");
			this.Property(t => t.MetaKey).HasColumnName("MetaKey");
			this.Property(t => t.MetaValue).HasColumnName("MetaValue");
		}
	}
}

