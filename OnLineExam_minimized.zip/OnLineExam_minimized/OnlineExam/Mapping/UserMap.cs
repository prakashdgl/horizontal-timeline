using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class UserMap : EntityTypeConfiguration<User>
	{
		public UserMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.UID)
				.IsRequired()
				.HasMaxLength(50);
				
			this.Property(t => t.Name)
				.IsRequired()
				.HasMaxLength(50);
				
			this.Property(t => t.Salt)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.Email)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.HashedPassword)
				.IsRequired()
				.HasMaxLength(256);
				
			// Table & Column Mappings
			this.ToTable("Users");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.UID).HasColumnName("UID");
			this.Property(t => t.Name).HasColumnName("Name");
			this.Property(t => t.Salt).HasColumnName("Salt");
			this.Property(t => t.Email).HasColumnName("Email");
			this.Property(t => t.HashedPassword).HasColumnName("HashedPassword");
			this.Property(t => t.Status).HasColumnName("Status");
			this.Property(t => t.CreatedAt).HasColumnName("CreatedAt");
			this.Property(t => t.UpdatedAt).HasColumnName("UpdatedAt");
		}
	}
}

