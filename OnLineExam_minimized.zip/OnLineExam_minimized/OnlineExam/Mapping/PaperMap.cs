using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class PaperMap : EntityTypeConfiguration<Paper>
	{
		public PaperMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.Name)
				.IsRequired()
				.HasMaxLength(256);
				
			// Table & Column Mappings
			this.ToTable("Papers");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.CategoryID).HasColumnName("CategoryID");
			this.Property(t => t.Name).HasColumnName("Name");
			this.Property(t => t.CreatedAt).HasColumnName("CreatedAt");
			this.Property(t => t.UpdatedAt).HasColumnName("UpdatedAt");

			// Relationships
			this.HasRequired(t => t.Category)
				.WithMany(t => t.Papers)
				.HasForeignKey(d => d.CategoryID);
				
		}
	}
}

