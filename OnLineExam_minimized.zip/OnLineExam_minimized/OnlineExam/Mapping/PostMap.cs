using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class PostMap : EntityTypeConfiguration<Post>
	{
		public PostMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.Title)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.Body)
				.IsRequired();
				
			// Table & Column Mappings
			this.ToTable("Posts");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.Title).HasColumnName("Title");
			this.Property(t => t.Clicks).HasColumnName("Clicks");
			this.Property(t => t.UserID).HasColumnName("UserID");
			this.Property(t => t.CategoryID).HasColumnName("CategoryID");
			this.Property(t => t.Body).HasColumnName("Body");
			this.Property(t => t.Status).HasColumnName("Status");
			this.Property(t => t.CreatedAt).HasColumnName("CreatedAt");
			this.Property(t => t.UpdatedAt).HasColumnName("UpdatedAt");

			// Relationships
			this.HasRequired(t => t.Category)
				.WithMany(t => t.Posts)
				.HasForeignKey(d => d.CategoryID);
				
			this.HasRequired(t => t.User)
				.WithMany(t => t.Posts)
				.HasForeignKey(d => d.UserID);
				
		}
	}
}

