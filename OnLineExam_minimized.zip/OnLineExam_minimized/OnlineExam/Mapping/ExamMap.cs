using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class ExamMap : EntityTypeConfiguration<Exam>
	{
		public ExamMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.Address)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.Syllabus)
				.IsRequired();
				
			this.Property(t => t.Notes)
				.IsRequired();
				
			// Table & Column Mappings
			this.ToTable("Exams");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.CategoryID).HasColumnName("CategoryID");
			this.Property(t => t.Address).HasColumnName("Address");
			this.Property(t => t.DateTime).HasColumnName("DateTime");
			this.Property(t => t.Syllabus).HasColumnName("Syllabus");
			this.Property(t => t.Notes).HasColumnName("Notes");
			this.Property(t => t.CreatedAt).HasColumnName("CreatedAt");
			this.Property(t => t.UpdatedAt).HasColumnName("UpdatedAt");

			// Relationships
			this.HasRequired(t => t.Category)
				.WithMany(t => t.Exams)
				.HasForeignKey(d => d.CategoryID);
				
		}
	}
}

