using System;
using System.Data.Entity.ModelConfiguration;
using System.Data.Common;
using System.Data.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using OnlineExam.Entities;

namespace OnlineExam.Mapping
{
	public class ExamMetaMap : EntityTypeConfiguration<ExamMeta>
	{
		public ExamMetaMap()
		{
			// Primary Key
			this.HasKey(t => t.ID);

			// Properties
			this.Property(t => t.MetaKey)
				.IsRequired()
				.HasMaxLength(256);
				
			this.Property(t => t.MetaValue)
				.IsRequired();
				
			// Table & Column Mappings
			this.ToTable("ExamMetas");
			this.Property(t => t.ID).HasColumnName("ID");
			this.Property(t => t.ExamID).HasColumnName("ExamID");
			this.Property(t => t.MetaKey).HasColumnName("MetaKey");
			this.Property(t => t.MetaValue).HasColumnName("MetaValue");

			// Relationships
			this.HasRequired(t => t.Exam)
				.WithMany(t => t.ExamMetas)
				.HasForeignKey(d => d.ExamID);
				
		}
	}
}

