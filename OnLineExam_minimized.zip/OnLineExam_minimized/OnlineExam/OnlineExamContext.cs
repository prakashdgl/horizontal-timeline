using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using OnlineExam.Entities;
using OnlineExam.Mapping;

namespace OnlineExam
{
	public class OnlineExamContext : DbContext
	{
		static OnlineExamContext()
		{ 
			Database.SetInitializer<OnlineExamContext>(null);
		}

		public DbSet<Attendance> Attendances { get; set; }
		public DbSet<Category> Categories { get; set; }
		public DbSet<Comment> Comments { get; set; }
		public DbSet<ExamMeta> ExamMetas { get; set; }
		public DbSet<Exam> Exams { get; set; }
		public DbSet<Link> Links { get; set; }
		public DbSet<MetaData> MetaDatas { get; set; }
		public DbSet<PaperMeta> PaperMetas { get; set; }
		public DbSet<Paper> Papers { get; set; }
		public DbSet<PostMeta> PostMetas { get; set; }
		public DbSet<Post> Posts { get; set; }
		public DbSet<ProblemMeta> ProblemMetas { get; set; }
		public DbSet<Problem> Problems { get; set; }
		public DbSet<UserMeta> UserMetas { get; set; }
		public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
            modelBuilder.Conventions.Remove<IncludeMetadataConvention>();
			modelBuilder.Configurations.Add(new AttendanceMap());
			modelBuilder.Configurations.Add(new CategoryMap());
			modelBuilder.Configurations.Add(new CommentMap());
			modelBuilder.Configurations.Add(new ExamMetaMap());
			modelBuilder.Configurations.Add(new ExamMap());
			modelBuilder.Configurations.Add(new LinkMap());
			modelBuilder.Configurations.Add(new MetaDataMap());
			modelBuilder.Configurations.Add(new PaperMetaMap());
			modelBuilder.Configurations.Add(new PaperMap());
			modelBuilder.Configurations.Add(new PostMetaMap());
			modelBuilder.Configurations.Add(new PostMap());
			modelBuilder.Configurations.Add(new ProblemMetaMap());
			modelBuilder.Configurations.Add(new ProblemMap());
			modelBuilder.Configurations.Add(new UserMetaMap());
			modelBuilder.Configurations.Add(new UserMap());
		}
	}
}

