﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace OnlineExam
{
    public partial class Dashboard : System.Web.UI.Page
    {
        public DashboardData data = null;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!User.Identity.IsAuthenticated)
            { Response.Redirect("/Account/Login"); }
        }

        
       public void GetDashboardData( )
        {
            data = new DashboardData();
            //Get Data required for the charts from database for the user in Session Variable.
              string[] strSubject = new string[4];
              int[] intCompletion = new int[4];
            int i = 0;
         
            try
            {
                string connstring = System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
              
                string strUserName = User.Identity.Name;
                
                //Create the connection object
                using (SqlConnection conn = new SqlConnection(connstring))
                {
                    // Open the SqlConnection.
                    conn.Open();
                    //Create the SQLCommand object
                    using (SqlCommand command = new SqlCommand("spGetStudentDashboardData", conn) { CommandType = System.Data.CommandType.StoredProcedure })
                    {
                        //Pass the parameter values here
                        command.Parameters.AddWithValue("@UserName",  strUserName );
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            //read the data
                            while (reader.Read())
                            {
                                var subject = new Subject() { Name = reader["SubjectName"].ToString(), Percentage = Convert.ToInt32(reader["Progress"]) };
                                data.Subjects.Add(subject);
                            }
                            
                        }
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                using (EventLog eventLog = new EventLog("Application"))
                {
                    eventLog.Source = "Application";
                    eventLog.WriteEntry("Error in Database Operation @ Getting Data for Charts in Dashboard Module", EventLogEntryType.Error, 101, 1);
                }
            }
        }

    }
}