using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using OnlineExam.Entities;
using OnlineExam;

namespace OnlineExam.Models
{ 
    public class ProblemMetaRepository : AppRepository<ProblemMeta>, IProblemMetaRepository
    {
    }

    public interface IProblemMetaRepository : IAppRepository<ProblemMeta>
    {
    }
}