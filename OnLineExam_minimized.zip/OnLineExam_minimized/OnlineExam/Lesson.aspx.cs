﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineExam
{
    public partial class Question : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated)
            { Response.Redirect("/Account/Login"); }
        }


        protected void ddBook_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView1.DataBind();
        }
        protected void ButtonAdd_Click(object sender, EventArgs e)
        {

            SqlDataSource2.InsertParameters["LessonNo"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("TextBox12")).Text;
            SqlDataSource2.InsertParameters["LessonName"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("TextBox13")).Text;
            SqlDataSource2.InsertParameters["TermNo"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("TextBox14")).Text;
            SqlDataSource2.InsertParameters["SubjectGradeBookID"].DefaultValue = ddBook.SelectedValue;
            SqlDataSource2.Insert();
        }

        protected void GridView1_RowDataBound(object sender,
                                 GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton l = (LinkButton)e.Row.FindControl("LinkButton1");
                l.Attributes.Add("onclick", "javascript:return " +
                "confirm('Are you sure you want to delete this record " +
                DataBinder.Eval(e.Row.DataItem, "CategoryID") + "')");
            }
        }

        protected void  GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            int a;
            a = 10;
        }
        protected void GridView1_RowDeleting(object sender, GridViewDeletedEventArgs e)
        {
            int a;
            a = 10;
        }
    }
}