﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections.Specialized;

namespace OnlineExam
{
	public class Config
	{
		private static NameValueCollection settings;

		static Config()
		{
			settings = new NameValueCollection();
			settings.Add(System.Configuration.ConfigurationManager.AppSettings);
		}

		public static string Get(string key)
		{
			return settings[key];
		}

		public static int GetInt(string key, int defaultVal = 0)
		{
			string val = Get(key);
			if(val == null)
				return defaultVal;
			try
			{
				return Convert.ToInt32(val);
			}
			catch (Exception ex)
			{
			}
			return defaultVal;
		}
	}
}