using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class ProblemMeta
	{
		public int ID { get; set; }
		public int ProblemID { get; set; }
		public string MetaKey { get; set; }
		public string MetaValue { get; set; }
		public virtual Problem Problem { get; set; }
	}
}

