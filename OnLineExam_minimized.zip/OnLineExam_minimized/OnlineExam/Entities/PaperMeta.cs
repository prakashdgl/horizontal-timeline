using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class PaperMeta
	{
		public int ID { get; set; }
		public int PaperID { get; set; }
		public string MetaKey { get; set; }
		public string MetaValue { get; set; }
		public virtual Paper Paper { get; set; }
	}
}

