using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class User
	{
	    public User()
		{
			this.Attendances = new List<Attendance>();
			this.Posts = new List<Post>();
			this.UserMetas = new List<UserMeta>();
		}

		public int ID { get; set; }
		public string UID { get; set; }
		public string Name { get; set; }
		public string Salt { get; set; }
		public string Email { get; set; }
		public string HashedPassword { get; set; }
		public byte Status { get; set; }
		public System.DateTime CreatedAt { get; set; }
		public System.DateTime UpdatedAt { get; set; }
		public virtual ICollection<Attendance> Attendances { get; set; }
		public virtual ICollection<Post> Posts { get; set; }
		public virtual ICollection<UserMeta> UserMetas { get; set; }
	}
}

