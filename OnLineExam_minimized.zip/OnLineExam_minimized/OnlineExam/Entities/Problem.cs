using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Problem
	{
	    public Problem()
		{
			this.ProblemMetas = new List<ProblemMeta>();
		}

		public int ID { get; set; }
		public int CategoryID { get; set; }
		public string Body { get; set; }
		public byte Type { get; set; }
		public System.DateTime CreatedAt { get; set; }
		public System.DateTime UpdatedAt { get; set; }
		public virtual Category Category { get; set; }
		public virtual ICollection<ProblemMeta> ProblemMetas { get; set; }
	}
}

