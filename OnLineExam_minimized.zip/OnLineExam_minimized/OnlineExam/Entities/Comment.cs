using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Comment
	{
		public int ID { get; set; }
		public string Target { get; set; }
		public int TargetID { get; set; }
		public string Name { get; set; }
		public string Email { get; set; }
		public string IP { get; set; }
		public int ParentID { get; set; }
		public string Body { get; set; }
		public bool Status { get; set; }
		public System.DateTime CreatedAt { get; set; }
		public System.DateTime UpdatedAt { get; set; }
	}
}

