using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Link
	{
		public int ID { get; set; }
		public string Url { get; set; }
		public string Name { get; set; }
		public string Description { get; set; }
		public int CategoryID { get; set; }
		public virtual Category Category { get; set; }
	}
}

