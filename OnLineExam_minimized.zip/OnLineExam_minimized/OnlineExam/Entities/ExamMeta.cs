using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class ExamMeta
	{
		public int ID { get; set; }
		public int ExamID { get; set; }
		public string MetaKey { get; set; }
		public string MetaValue { get; set; }
		public virtual Exam Exam { get; set; }
	}
}

