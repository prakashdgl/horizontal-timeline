using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Post
	{
	    public Post()
		{
			this.PostMetas = new List<PostMeta>();
		}

		public int ID { get; set; }
		public string Title { get; set; }
		public int Clicks { get; set; }
		public int UserID { get; set; }
		public int CategoryID { get; set; }
		public string Body { get; set; }
		public bool Status { get; set; }
		public System.DateTime CreatedAt { get; set; }
		public System.DateTime UpdatedAt { get; set; }
		public virtual Category Category { get; set; }
		public virtual ICollection<PostMeta> PostMetas { get; set; }
		public virtual User User { get; set; }
	}
}

