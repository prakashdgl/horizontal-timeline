using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class MetaData
	{
		public int ID { get; set; }
		public string Family { get; set; }
		public string MetaKey { get; set; }
		public string MetaValue { get; set; }
	}
}

