using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class UserMeta
	{
		public int ID { get; set; }
		public int UserID { get; set; }
		public string MetaKey { get; set; }
		public string MetaValue { get; set; }
		public virtual User User { get; set; }
	}
}

