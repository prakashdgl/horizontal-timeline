using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Category
	{
	    public Category()
		{
			this.Exams = new List<Exam>();
			this.Links = new List<Link>();
			this.Papers = new List<Paper>();
			this.Posts = new List<Post>();
			this.Problems = new List<Problem>();
		}

		public int ID { get; set; }
		public string Taxonomy { get; set; }
		public string Name { get; set; }
		public int ParentID { get; set; }
		public virtual ICollection<Exam> Exams { get; set; }
		public virtual ICollection<Link> Links { get; set; }
		public virtual ICollection<Paper> Papers { get; set; }
		public virtual ICollection<Post> Posts { get; set; }
		public virtual ICollection<Problem> Problems { get; set; }
	}
}

