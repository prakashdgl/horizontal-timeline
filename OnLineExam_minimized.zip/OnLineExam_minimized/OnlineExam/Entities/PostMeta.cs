using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class PostMeta
	{
		public int ID { get; set; }
		public int PostID { get; set; }
		public string MetaKey { get; set; }
		public string MetaValue { get; set; }
		public virtual Post Post { get; set; }
	}
}

