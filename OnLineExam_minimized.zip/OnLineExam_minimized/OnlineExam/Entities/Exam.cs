using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Exam
	{
	    public Exam()
		{
			this.Attendances = new List<Attendance>();
			this.ExamMetas = new List<ExamMeta>();
		}

		public int ID { get; set; }
		public int CategoryID { get; set; }
		public string Address { get; set; }
		public System.DateTime DateTime { get; set; }
		public string Syllabus { get; set; }
		public string Notes { get; set; }
		public System.DateTime CreatedAt { get; set; }
		public System.DateTime UpdatedAt { get; set; }
		public virtual ICollection<Attendance> Attendances { get; set; }
		public virtual Category Category { get; set; }
		public virtual ICollection<ExamMeta> ExamMetas { get; set; }
	}
}

