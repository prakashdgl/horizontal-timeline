using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Attendance
	{
		public int ID { get; set; }
		public int ExamID { get; set; }
		public int UserID { get; set; }
		public System.DateTime StartedAt { get; set; }
		public System.DateTime EndedAt { get; set; }
		public byte Status { get; set; }
		public string Score { get; set; }
		public System.DateTime CreatedAt { get; set; }
		public System.DateTime UpdatedAt { get; set; }
		public virtual Exam Exam { get; set; }
		public virtual User User { get; set; }
	}
}

