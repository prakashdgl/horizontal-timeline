using System;
using System.Collections.Generic;

namespace OnlineExam.Entities
{
	public class Paper
	{
	    public Paper()
		{
			this.PaperMetas = new List<PaperMeta>();
		}

		public int ID { get; set; }
		public int CategoryID { get; set; }
		public string Name { get; set; }
		public System.DateTime CreatedAt { get; set; }
		public System.DateTime UpdatedAt { get; set; }
		public virtual Category Category { get; set; }
		public virtual ICollection<PaperMeta> PaperMetas { get; set; }
	}
}

